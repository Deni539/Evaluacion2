/*var nombres = document.getElementById('nombres');
var apellidop = document.getElementById('apellidop');
var apellidom = document.getElementById('apellidom');
var rut = document.getElementById('rut');
var direccion = document.getElementById('direccion');
var correo = document.getElementById('correo');
var telefono = document.getElementById('telefono');
var error = document.getElementById('error');


function enviarformulario(){
    console.log("Enviendo formulario");
    var mensajeserror =[];

    if(nombres.value === null || nombres.value === ""){
        mensajeserror.push("Ingresa nombres");
    }
    if(apellidop.value === null || apellidop.value === ""){
        mensajeserror.push("Ingresa apellido paterno");
    }
    if(apellidom.value === null || apellidom.value === ""){
        mensajeserror.push("Ingresa apellido materno");
    }
    
    error.innerHTML = mensajeserror.join(" , ")
    return false;
}*/